STAGE=staging
cp ../src/matcher.py .
rm function.zip
zip -r9 function.zip .
aws s3 cp function.zip s3://tdr-backend-checks-staging/yara-av.zip
aws lambda update-function-code --function-name tdr-yara-av-$STAGE --s3-bucket tdr-backend-checks-$STAGE --s3-key yara-av.zip
aws lambda publish-version --function-name tdr-yara-av-$STAGE
